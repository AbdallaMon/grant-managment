import PaymentCalendar from "@/app/UiComponents/admin/PaymentsCalendar";

export default function page() {
    return <PaymentCalendar/>
}