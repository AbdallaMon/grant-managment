import DocumentsPanel from "@/app/UiComponents/DataViewer/Documents";

export default function page() {
  return <DocumentsPanel isAdmin={true} />;
}
