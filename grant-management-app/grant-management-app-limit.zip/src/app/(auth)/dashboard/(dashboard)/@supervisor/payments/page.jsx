import PaymentCalendar from "@/app/UiComponents/admin/PaymentsCalendar";

export default function PaymentsPage() {
    return <PaymentCalendar/>
}