"use client";

import ResidenceInfo from "@/app/UiComponents/student/ResidenceInfo";

export default function page({params: {id}}) {

    return <ResidenceInfo id={id} extraParams={"status=UN_COMPLETE&"}/>
}
