export const metadata = {
    title: "الشكاوي والمقترحات"
}
export default function Layout({children}) {
    return children
}