import InvoicesPage from "@/app/UiComponents/DataViewer/InvoicesPage";

export default function page() {
    return <InvoicesPage isSupervisor={true}/>
}