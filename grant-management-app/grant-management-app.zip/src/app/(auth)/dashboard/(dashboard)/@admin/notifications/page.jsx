import NotificationsPage from "@/app/UiComponents/DataViewer/NotificationPage";

export const metadata = {
    title: "صفحة الاشعارات"
}
export default function page() {
    return <NotificationsPage/>
}