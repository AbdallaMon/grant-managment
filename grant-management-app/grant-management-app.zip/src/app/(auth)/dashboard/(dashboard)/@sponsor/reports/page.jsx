import ReportsPage from "@/app/UiComponents/report/ReportsPage";

export default function page() {
  return <ReportsPage />;
}
