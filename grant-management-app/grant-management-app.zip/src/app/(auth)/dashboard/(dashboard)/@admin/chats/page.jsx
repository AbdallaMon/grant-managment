import ChatPage from "@/app/UiComponents/DataViewer/ChatPage";

export const metadata = {
    title: "غرفة الدردشة"
}
export default function Chats() {
    return <ChatPage/>
}