export const metadata = {
    title: "طلبات المنح"
    , description: "طلبات المنح التي قدمتها بجميع حالتها"
}
export default function Layout({children}) {
    return children
}